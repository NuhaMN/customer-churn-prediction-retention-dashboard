import { motion } from 'framer-motion';
import Sidebar from '../components/Sidebar';
import Header from '../components/Header';

function MainLayout({ children }) {
  return (
    <div className="flex min-h-screen bg-primary text-silver font-sans">
      <Sidebar />
      <div className="flex flex-col flex-1 ml-64">
        <Header />
        <motion.main
          className="p-6 overflow-auto"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          {children}
        </motion.main>
      </div>
    </div>
  );
}

export default MainLayout;
