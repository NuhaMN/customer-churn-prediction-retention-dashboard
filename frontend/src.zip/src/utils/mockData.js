export const mockStats = {
  totalCustomers: 12456,
  highRisk: 342,
  revenueAtRisk: 1_250_000,
  retentionOps: 87,
  modelAccuracy: 92.4,
  predictionConfidence: 88.1,
};

export const mockCharts = {
  churnDistribution: [
    { name: 'Low', value: 60 },
    { name: 'Medium', value: 25 },
    { name: 'High', value: 15 },
  ],
  revenueImpact: [
    { month: 'Jan', revenue: 120000 },
    { month: 'Feb', revenue: 115000 },
    { month: 'Mar', revenue: 130000 },
    { month: 'Apr', revenue: 125000 },
  ],
};

export const mockCustomers = [
  {
    id: 'C001',
    name: 'Alice Johnson',
    risk: 78,
    contract: 'Month-to-month',
    services: ['Streaming', 'Tech Support'],
    charges: 89.99,
  },
  {
    id: 'C002',
    name: 'Bob Smith',
    risk: 34,
    contract: 'One year',
    services: ['Streaming'],
    charges: 56.45,
  },
];

export const mockRecommendations = [
  { title: 'Offer 20% Discount', impact: '-15% churn', type: 'discount' },
  { title: 'Upgrade to Premium Support', impact: '-10% churn', type: 'support' },
];
