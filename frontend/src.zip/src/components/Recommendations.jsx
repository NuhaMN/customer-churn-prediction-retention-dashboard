export default function Recommendations() {
    return (
        <div className="glass-card p-6 text-white">
            <h2 className="text-xl font-bold">Recommendations</h2>
            <p className="text-gray-400 mt-2">
                AI recommendations will appear here.
            </p>
        </div>
    )
}