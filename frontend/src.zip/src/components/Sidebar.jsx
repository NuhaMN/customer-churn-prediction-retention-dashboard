import React from 'react';
import { NavLink } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  LayoutDashboard,
  Users,
  BarChart2,
  TrendingUp,
  FileText,
  Settings,
  PieChart,
  ClipboardList
} from 'lucide-react';

const links = [
  { to: '/', label: 'Overview', icon: LayoutDashboard },
  { to: '/customers', label: 'Customers', icon: Users },
  { to: '/predictions', label: 'Predictions', icon: BarChart2 },
  { to: '/retention', label: 'Retention', icon: TrendingUp },
  { to: '/analytics', label: 'Analytics', icon: PieChart },
  { to: '/reports', label: 'Reports', icon: ClipboardList },
  { to: '/settings', label: 'Settings', icon: Settings },
];

const Sidebar = () => (
  <motion.nav
    initial={{ x: -200, opacity: 0 }}
    animate={{ x: 0, opacity: 1 }}
    className="fixed inset-y-0 left-0 w-64 bg-[#1A1A24] bg-opacity-90 backdrop-blur-lg border-r border-[#2A2A34] p-6 overflow-y-auto"
  >
    <h2 className="text-2xl font-bold text-[#E0E0E0] mb-8">AI Dashboard</h2>
    <ul className="space-y-4">
      {links.map(({ to, label, icon: Icon }) => (
        <li key={to}>
          <NavLink
            to={to}
            className={({ isActive }) =>
              `flex items-center space-x-3 p-3 rounded-lg transition-all duration-200 
               ${isActive ? 'bg-[#00F2FE] text-[#0F0F12]' : 'text-[#A0AEC0] hover:bg-[#00F2FE]/20'}
               hover:shadow-glow`
            }
          >
            <Icon className="w-5 h-5" />
            <span className="font-medium">{label}</span>
          </NavLink>
        </li>
      ))}
    </ul>
  </motion.nav>
);

export default Sidebar;
