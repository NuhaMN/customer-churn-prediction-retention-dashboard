import React from 'react';
import { motion } from 'framer-motion';
import CountUp from 'react-countup';
import { mockStats } from '../utils/mockData';

const cards = [
  { label: 'Total Customers', value: mockStats.totalCustomers, color: '#00F2FE' },
  { label: 'High‑Risk Customers', value: mockStats.highRisk, color: '#FF00FF' },
  { label: 'Revenue at Risk', value: `$${mockStats.revenueAtRisk.toLocaleString()}`, color: '#00E676' },
  { label: 'Retention Opportunities', value: mockStats.retentionOps, color: '#00F2FE' },
  { label: 'Model Accuracy', value: `${mockStats.modelAccuracy}%`, color: '#FF00FF' },
  { label: 'Prediction Confidence', value: `${mockStats.predictionConfidence}%`, color: '#00E676' },
];

const KpiCards = () => (
  <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-2 gap-4">
    {cards.map((c) => (
      <motion.div
        key={c.label}
        className="glass-card p-4 text-center"
        style={{ border: `2px solid ${c.color}` }}
        whileHover={{ scale: 1.03, boxShadow: `0 0 12px ${c.color}` }}
        transition={{ type: 'spring', stiffness: 300 }}
      >
        <div className="text-sm text-[#A0AEC0] mb-1">{c.label}</div>
        <div className="text-2xl font-bold" style={{ color: c.color }}>
          <CountUp
            end={typeof c.value === 'string' ? parseFloat(c.value.replace(/[^0-9.]/g, '')) : c.value}
            separator="," duration={2}
          />
          {typeof c.value === 'string' && c.value.includes('%') ? '%' : ''}
        </div>
      </motion.div>
    ))}
  </div>
);

export default KpiCards;
