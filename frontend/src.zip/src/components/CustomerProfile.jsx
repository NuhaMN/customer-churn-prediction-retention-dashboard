export default function CustomerProfile() {
    return (
        <div className="glass-card p-6 text-white">
            <h2 className="text-xl font-bold">Customer Profile</h2>
            <p className="text-gray-400 mt-2">
                Customer details will appear here.
            </p>
        </div>
    )
}