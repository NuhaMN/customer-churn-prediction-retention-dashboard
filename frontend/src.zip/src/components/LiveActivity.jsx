export default function LiveActivity() {
    return (
        <div className="glass-card p-4 text-white">
            <h2 className="text-xl font-semibold">Live Activity</h2>
            <p className="text-gray-400 mt-2">
                Live activity component loaded successfully.
            </p>
        </div>
    );
}