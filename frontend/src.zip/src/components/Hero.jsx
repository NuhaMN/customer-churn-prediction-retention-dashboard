import React from 'react';
import { motion } from 'framer-motion';
import { mockStats } from '../utils/mockData';

const Hero = () => (
  <section className="mb-8 text-center">
    <motion.h1
      className="text-4xl font-bold text-[#E0E0E0] mb-2"
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      AI‑Powered Customer Churn Intelligence
    </motion.h1>
    <motion.div
      className="inline-block px-4 py-1 rounded-full bg-[#00F2FE] text-[#0F0F12] font-medium"
      initial={{ scale: 0 }}
      animate={{ scale: 1 }}
      transition={{ delay: 0.4, type: 'spring' }}
    >
      System Status: Operational
    </motion.div>
    <p className="mt-2 text-[#A0AEC0]">
      {`Model Accuracy: ${mockStats.modelAccuracy}% • Prediction Confidence: ${mockStats.predictionConfidence}%`}
    </p>
  </section>
);

export default Hero;
