export default function RiskGauge() {
    return (
        <div className="glass-card p-6 text-white">
            <h2 className="text-xl font-bold">Risk Gauge</h2>
            <p className="text-gray-400 mt-2">
                Risk visualization will appear here.
            </p>
        </div>
    )
}