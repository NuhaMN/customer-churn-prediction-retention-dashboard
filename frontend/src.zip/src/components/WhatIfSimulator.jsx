export default function WhatIfSimulator() {
    return (
        <div className="glass-card p-4 text-white">
            <h2 className="text-xl font-semibold">What-If Simulator</h2>
            <p className="text-gray-400 mt-2">
                What-if simulation component loaded successfully.
            </p>
        </div>
    );
}