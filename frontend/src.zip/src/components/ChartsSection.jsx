import React from 'react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, LineChart, Line, Legend } from 'recharts';
import { mockCharts } from '../utils/mockData';
import { motion } from 'framer-motion';

const ChartsSection = () => (
  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
    {/* Churn Distribution Bar Chart */}
    <motion.div
      className="glass-card p-4"
      whileHover={{ scale: 1.02 }}
    >
      <h3 className="text-[#E0E0E0] mb-2">Churn Distribution</h3>
      <ResponsiveContainer width="100%" height={250}>
        <BarChart data={mockCharts.churnDistribution}>
          <CartesianGrid strokeDasharray="3 3" stroke="#444" />
          <XAxis dataKey="name" stroke="#AAA" />
          <YAxis stroke="#AAA" />
          <Tooltip contentStyle={{ backgroundColor: '#222', border: 'none' }} />
          <Bar dataKey="value" fill="var(--tw-gradient-from, #00F2FE)" />
        </BarChart>
      </ResponsiveContainer>
    </motion.div>

    {/* Revenue Impact Line Chart */}
    <motion.div
      className="glass-card p-4"
      whileHover={{ scale: 1.02 }}
    >
      <h3 className="text-[#E0E0E0] mb-2">Revenue Impact (Last 4 Months)</h3>
      <ResponsiveContainer width="100%" height={250}>
        <LineChart data={mockCharts.revenueImpact}>
          <CartesianGrid strokeDasharray="3 3" stroke="#444" />
          <XAxis dataKey="month" stroke="#AAA" />
          <YAxis stroke="#AAA" />
          <Tooltip contentStyle={{ backgroundColor: '#222', border: 'none' }} />
          <Line type="monotone" dataKey="revenue" stroke="#FF00FF" strokeWidth={3} dot={{ fill: '#FF00FF' }} />
        </LineChart>
      </ResponsiveContainer>
    </motion.div>
  </div>
);

export default ChartsSection;
