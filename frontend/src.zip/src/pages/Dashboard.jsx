import React from 'react';
import Hero from '../components/Hero';
import KpiCards from '../components/KpiCards';
import ChartsSection from '../components/ChartsSection';
import RiskGauge from '../components/RiskGauge';
import CustomerProfile from '../components/CustomerProfile';
import Recommendations from '../components/Recommendations';
import WhatIfSimulator from '../components/WhatIfSimulator';
import LiveActivity from '../components/LiveActivity';

export default function Dashboard() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 p-4">
      {/* Left/main area (spans two columns) */}
      <div className="lg:col-span-2 space-y-6">
        <Hero />
        <KpiCards />
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <ChartsSection />
          <RiskGauge />
        </div>
      </div>

      {/* Right side panel */}
      <div className="space-y-6">
        <CustomerProfile />
        <Recommendations />
        <WhatIfSimulator />
        <LiveActivity />
      </div>
    </div>
  );
}
